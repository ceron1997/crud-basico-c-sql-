﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using capa_convercion;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace formulario_registro
{
    public partial class Form1 : Form
    {
        convercion objetod = new convercion();
        private string id = null;
        private bool editar = false;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'registro_personalDataSet.area' Puede moverla o quitarla según sea necesario.
            this.areaTableAdapter.Fill(this.registro_personalDataSet.area);
            mostrardatos();
        }
        private void mostrardatos()
        {
            convercion objeto = new convercion();
            lista_registro.DataSource = objeto.mostrarpersonal();
        }
        private void limpiar()
        {
            txtnombre.Clear();
            txtapellido.Text = "";
            txtdni.Clear();
            txtcelular.Clear();
            txtcodigo.Clear();
        }
        public Boolean esnumero(String cadena)
        {


            if (cadena.All(char.IsDigit))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
        }
        private void button4_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void lista_registro_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
           
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            }


     

        private void button1_Click_1(object sender, EventArgs e)
        {

            if (!(esnumero(txtdni.Text))) {
                MessageBox.Show("ingrese valores validos ");
                return; 
            }
            if (!(esnumero(txtcelular.Text)))
            {
                MessageBox.Show("ingrese valores validos ");
                return;
            }

            if (editar == false)
            {
              
                try
                {

                    int index = cbxArea.SelectedIndex + 1;
                    objetod.insertardaro(txtnombre.Text, txtapellido.Text, txtdni.Text, txtcelular.Text,index);

                    MessageBox.Show("se inserto correctamente");
                    mostrardatos();
                    limpiar();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("no se pudo insertar los datos por: " + ex);
                }
            }
            if (editar == true)
            {
                if (!(esnumero(txtdni.Text)))
                {
                    MessageBox.Show("ingrese valores validos ");
                    return;
                }
                if (!(esnumero(txtcelular.Text)))
                {
                    MessageBox.Show("ingrese valores validos ");
                    return;
                }

                try
                {
                    int index = cbxArea.SelectedIndex + 1;
                    
                    objetod.editardato(txtnombre.Text, txtapellido.Text, txtdni.Text, txtcelular.Text, index, id);
                    MessageBox.Show("se edito correctamente");
                    mostrardatos();
                    limpiar();
                    editar = false;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("no se pudo editar los datos por: " + ex);
                }
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            if (lista_registro.SelectedRows.Count > 0)
            {
                editar = true;
                txtnombre.Text = lista_registro.CurrentRow.Cells["nombre"].Value.ToString();
                txtapellido.Text = lista_registro.CurrentRow.Cells["apellido"].Value.ToString();
                txtdni.Text = lista_registro.CurrentRow.Cells["dni"].Value.ToString();
                txtcelular.Text = lista_registro.CurrentRow.Cells["celular"].Value.ToString();
                cbxArea.Text = lista_registro.CurrentRow.Cells["area"].Value.ToString();
                id = lista_registro.CurrentRow.Cells["id"].Value.ToString();
                txtcodigo.Text = lista_registro.CurrentRow.Cells["id"].Value.ToString();
            }
            else
                MessageBox.Show("seleccione una fila por favor");

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            if (lista_registro.SelectedRows.Count > 0)
            {
                id = lista_registro.CurrentRow.Cells["Id"].Value.ToString();
                objetod.eliminardata(id);
                MessageBox.Show("Eliminado correctamente");
                mostrardatos();
            }
            else
                MessageBox.Show("seleccione una fila por favor");

        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            Close();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
    }
}
