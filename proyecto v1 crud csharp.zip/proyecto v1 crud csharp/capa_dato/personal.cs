﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
namespace capa_dato
{
    public class personal
    {
        private conexiones conexion = new conexiones();

        SqlDataReader leer;
        DataTable tabla = new DataTable();
        SqlCommand comando = new SqlCommand();

        public DataTable mostrar()
        {

            comando.Connection = conexion.abrir();
            comando.CommandText = "mostrardatos";
            comando.CommandType = CommandType.StoredProcedure;
            leer = comando.ExecuteReader();
            tabla.Load(leer);
            conexion.cerrar();
            return tabla;

        }

        public void insertar(string nombre, string apellido, String dni, String celular, int cargo)
        {


            comando.Connection = conexion.abrir();
            comando.CommandText = "insertarpersonal";
            comando.CommandType = CommandType.StoredProcedure;
            comando.Parameters.AddWithValue("@nombre", nombre);
            comando.Parameters.AddWithValue("@apellido", apellido);
            comando.Parameters.AddWithValue("@dni", dni);
            comando.Parameters.AddWithValue("@celular", celular);
            comando.Parameters.AddWithValue("@cargo", cargo);

            comando.ExecuteNonQuery();

            comando.Parameters.Clear();

        }

        public void editar(string nombre, string apellido, String dni, String celular, int cargo, int id)
        {

            comando.Connection = conexion.abrir();
            comando.CommandText = "editarpersonal";
            comando.CommandType = CommandType.StoredProcedure;
            comando.Parameters.AddWithValue("@nombre", nombre);
            comando.Parameters.AddWithValue("@apellido", apellido);
            comando.Parameters.AddWithValue("@dni", dni);
            comando.Parameters.AddWithValue("@celular", celular);
            comando.Parameters.AddWithValue("@cargo", cargo);
            comando.Parameters.AddWithValue("@id", id);

            comando.ExecuteNonQuery();

            comando.Parameters.Clear();
        }

        public void eliminar(int id)
        {
            comando.Connection = conexion.abrir();
            comando.CommandText = "eliminarpersonal";
            comando.CommandType = CommandType.StoredProcedure;

            comando.Parameters.AddWithValue("@id", id);

            comando.ExecuteNonQuery();

            comando.Parameters.Clear();
        }

       



    }


}
