﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace capa_dato
{
    class conexiones
    {
        private SqlConnection conexion = new SqlConnection("Data Source= DESKTOP-RGU9HIH\\SQLEXPRESS;Initial Catalog=registro_personal;Integrated Security=True;");

        public SqlConnection abrir()
        {
            if (conexion.State == ConnectionState.Closed)
                conexion.Open();
            return conexion;
        }

        public SqlConnection cerrar()
        {
            if (conexion.State == ConnectionState.Open)
                conexion.Close();
            return conexion;
        }
    }
}
