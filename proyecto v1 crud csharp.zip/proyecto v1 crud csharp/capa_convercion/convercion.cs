﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using capa_dato;
using System.Data;
namespace capa_convercion
{
    public class convercion
    {
        private personal objetoc = new personal();

        public DataTable mostrarpersonal()
        {

            DataTable tabla = new DataTable();
            tabla = objetoc.mostrar();
            return tabla;
        }
        public void insertardaro(string nombre, string apellido, string dni, string celular, int cargo)
        {

            objetoc.insertar(nombre, apellido, dni, celular, cargo);
        }

        public void editardato(string nombre, string apellido, string dni, string celular, int  cargo, string id)
        {
            objetoc.editar(nombre, apellido, dni, celular, cargo, Convert.ToInt32(id));
        }

        public void eliminardata(string id)
        {

            objetoc.eliminar(Convert.ToInt32(id));
        }
    }
}
